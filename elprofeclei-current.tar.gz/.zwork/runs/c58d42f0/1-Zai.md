# Z.ai — run c58d42f0 participant 1

Verificación literal: ambos comandos sin salida, exit 0.

(a) Reescrito :zwork-file-citation{path="packages/web/src/pages/InstructorPanel.tsx" purpose="output" artifact_kind="document"}; nuevo :zwork-file-citation{path="packages/web/src/components/CourseFormModal.tsx" purpose="output" artifact_kind="document"}; :zwork-file-citation{path="packages/web/src/services/courses.service.ts" purpose="output" artifact_kind="document"} (tipado getMyCourses; CourseUpdateInput sin status).

(b) Antes: form de creación fijo + filas sin estados (errores a console.error). Ahora: encabezado con resumen real (total/publicados/en revisión/borradores) + «Crear curso»; formulario único en Modal (crear/editar); tarjetas con badge textual, modalidad·horas, precio formatCOP/«Gratis» y acciones por estado.

(c) Carga: esqueletos tipo tarjeta; vacío con CTA; error con causa+«Reintentar»; lleno. Form: courseSchema+zodResolver, mode onTouched, htmlFor, aria-invalid/describedby, role=alert por campo, precio con vista formatCOP. A11y: focus-visible AA, teclado, toasts role=status, SVG 1.7, motion-reduce.

(d) eslint → salida vacía; tsc → salida vacía. Exit 0 ambos.

(e) Al editar bloqueo modalidad/duración: el PATCH real solo acepta título/descripción/precio (api/src/modules/courses/course.service.ts), evito ediciones ignoradas en silencio. El foco inicial del modal de borrado cae en la «×» (Modal.tsx, intocable, enfoca el primer enfocable); «Cancelar» queda a un tab. Sin bloqueos del guardia.