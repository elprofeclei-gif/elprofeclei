# Z.ai — run b4e1c8a4 participant 0

**Hecho.** Catálogo con filtros, búsqueda, paginación y métricas reales; verificado sobre línea base previa en verde (39 tests).

**(a) Archivos:** `packages/shared/src/schemas/course.schema.ts` (+`courseQuerySchema`), `packages/api/src/modules/courses/course.service.ts` (`getPublished`: filtros, orden, skip/take, count y stats en un solo findMany+include, sin N+1), `course.controller.ts` (cabeceras), nuevo `test/courses.test.ts` (12 tests). Detalle y salidas completas en :zwork-file-citation{path="docs/api-marketplace.md" purpose="output" artifact_kind="document"}.

**(b) Query (todo opcional):** `q` ≤80 (title/description, insensitive) · `modality` VIRTUAL/ONSITE/HYBRID · `duration` EIGHT/TEN/SIXTEEN/TWENTY · `price` free|paid · `sort` recent (def.)|price_asc|price_desc (recent=createdAt desc) · `page` ≥1 def.1 · `pageSize` 1..48 def.12. Inválida ⇒ 400. Cuerpo: array (sin cambios) con `stats` real por curso; cabeceras `X-Total-Count`, `X-Page`, `X-Page-Size`.

**(c) Literal:** tsc → sin salida, exit 0 · eslint → sin salida, exit 0 · npm test → "Test Files 5 passed (5)" y "Tests 51 passed (51)".

**(d)** Sin bloqueos; seed, schema.prisma, auth/ y web/api.ts intactos. Única incidencia: 1ª pasada de eslint dio 26 errores CRLF en course.schema.ts; corregidos con `eslint --fix` y re-verificado en verde.